# Hello World Getting Started Sample

## Next Steps

- To run the JavaScript implementation, open a new terminal and run `cds watch`.
- To run the TypeScript implementation, open a new terminal and run `cds-ts watch`.

Then call the service at: http://localhost:4004/say/hello(to='world')

## Learn More

Learn more about:

- [Hello World!](https://cap.cloud.sap/docs/get-started/hello-world)
- [Using TypeScript](https://cap.cloud.sap/docs/node.js/typescript)
